

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class laptop
 */
@WebServlet("/laptop")
public class laptop extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		   PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			
			int price = Integer.parseInt(request.getParameter("price"));
			int quantity=Integer.parseInt(request.getParameter("quantity"));
			int totalprice = price *quantity;
			out.print("<h3> price = "+ price +"</h3");
			
			out.print("<h3> quantity = "+ quantity +"</h3>");
			
			out.print("<h3> total price = "+ totalprice +"</h3>");
			
			out.print("the above item is added is the cart");
			
			Cookie ck = new Cookie("laptop",String.valueOf(totalprice));
			response.addCookie(ck);
			
			
			out.print("<a herf='mycart'>mycart</a>");
	
	}

}
