package com.fijitsu.springjdbc.FujitsuSpringJDBC;

public class student {
	int id;
	String name;
	int salary;
	public student(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public student(Integer id2, String name2, Integer salary2) {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "student [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	

}
