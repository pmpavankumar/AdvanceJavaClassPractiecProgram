package com.fijitsu.springjdbc.FujitsuSpringJDBC;

import java.util.List;
import java.sql.ResultSet;
import java.sql.RowId;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 *spring jdbc
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//connect to database
        DriverManagerDataSource dataSourse = new DriverManagerDataSource();
    
    dataSourse.setDriverClassName("com.mysql.jdbc.Driver");
    dataSourse.setUrl("jdbc:mysql://localhost:3306/traininfo");
    dataSourse.setUsername("root");
    dataSourse.setPassword("india@123");
    System.out.println("connected");
    
    JdbcTemplate jdbcTemplete = new JdbcTemplate(dataSourse);
  //insert
//    String sql ="insert into Stduent(id,name)values(?,?)";
//    int result = jdbcTemplete.update(sql,105,"abcd");
   //update
//    String sql ="update  Stduent name=? where id=?";
//    int result = jdbcTemplete.update(sql,"dcba",101);
    //delete query
//    String sql ="delete from Stduent where id=?";
//    int result = jdbcTemplete.update(sql,101);
//   retrive(reading data),RowMapper-->result
    //loopthrough all the record from result set
    //put all the records in to a arraylist
    
    String query ="select * from student";
    RowMapper<student> rowMap = new RowMapper<student>() {
    	public student mapRow(ResultSet rs,int rownum) throws SQLException{
    		
    		Integer id = rs.getInt("id");
    		String name = rs.getNString("name");
    		Integer salary = rs.getInt("slary");
    		return new student(id, name, salary);
    	}
    };
    List<student> students =jdbcTemplete.query(sql, rowMap);
    
    for(stduent idd: students)
    {
    	System.out.println(idd);
    }
    
    
    }
}
