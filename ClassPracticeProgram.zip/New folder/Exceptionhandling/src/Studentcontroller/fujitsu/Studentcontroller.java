package Studentcontroller.fujitsu;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.fujitsu.students;

/**
 * Servlet implementation class Studentcontroller
 */
@WebServlet("/Studentcontroller")
public class Studentcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//System.out.println("running students controller.");
	
	int studentId = Integer.parseInt(request.getParameter("sid"));
	String studentName = request.getParameter("sname");
	
	//Student student =new student();
	//student.setId(studentId);
	//Student.setName(studentName);
	
	students model = new students(studentId,studentName);
	
	
	request.setAttribute("student", model);
	RequestDispatcher rd =request.getRequestDispatcher("display.jsp");
	rd.forward(request,response);
	
	System.out.println(model);
	}

}
