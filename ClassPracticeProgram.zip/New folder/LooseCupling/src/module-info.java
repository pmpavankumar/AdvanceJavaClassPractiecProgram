module LooseCupling {
}