package com.abstraction;

public class Kotak extends Bank {

	@Override
	double getRateOfIntrest() {
	
		return 4.5;
	}

}
