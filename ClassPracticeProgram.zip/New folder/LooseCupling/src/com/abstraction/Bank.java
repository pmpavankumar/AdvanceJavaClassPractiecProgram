package com.abstraction;

abstract class Bank {
	abstract double getRateOfIntrest();

}
