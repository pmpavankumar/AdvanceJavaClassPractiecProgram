package com.abstraction;

public class SBI extends Bank {

	@Override
	double getRateOfIntrest() {
	
		return 4.9;
	}
	

}
