package com.fujitsu.customTag;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.tagext.Tag;

public class Resulthandler extends TagSupport{

	Connection conn;
	PreparedStatement stmt;
	
	public Resulthandler() {
		try
	{
		Class.forName("com.mysql.jdbc.Driver");
	
	conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","india@123");
	
	stmt = conn.prepareStatement("select * from student where name =?");
	
	}catch( Exception  e) {
		e.printStackTrace();
	}
	}

	@Override
	public int doStartTag() throws JspException {
			ServletRequest request =pageContext.getRequest();
			String name = request.getParameter("username");
			try
			{
			stmt.setString(1,name);
			ResultSet rs =stmt.executeQuery();
			JspWriter out=pageContext.getOut();
			
					if(rs.next()) {
						System.out.println("id: " +rs.getString(1));
						System.out.println("name: " +rs.getString(1));
					}
					} catch (SQLException e)
					{
						e.printStackTrace();
					}
					
					return Tag.SKIP_BODY;
	}
	
	@Override
	public void release()
	{
		try {
			stmt.close();
			conn.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		super.release();
	
	}
}
